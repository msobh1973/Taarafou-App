document.addEventListener('DOMContentLoaded', () => {
    console.log('Taarafou site is ready!');
});
